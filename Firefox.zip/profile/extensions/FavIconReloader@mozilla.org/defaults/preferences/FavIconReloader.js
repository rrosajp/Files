/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

pref("extensions.FavIconReloader.maxTasks", "10");
pref("extensions.FavIconReloader.timeout", "15");
pref("extensions.FavIconReloader.showDebugText", false);
