pref("extensions.fastdial@telega.phpnet.us.description", "chrome://fastdial/locale/fastdial.properties");
pref("extensions.fastdial.slowSites", "gmail.com|mail\\.google|google\\.com\\/mail|reader\\.google|google\\.com\\/reader");
pref("extensions.fastdial.options", "{ \"width\": 3, \"height\": 3, \"thumbWidth\": 300, \"timeout\": 1000 }");
pref("extensions.fastdial.enable", true);
pref("view_source.tab", false);