Greetings!

If you're reading this file, then it looks like you've unpacked this extension and you have certainly no ideas how to install it.

In fact, there's no need to unpack the .XPI files to install them in Mozilla products.

To install an .XPI extension in the current user profile, simply click the Install button on Firefox Add-ons or drag the .XPI file into any Firefox window or open it from the File menu.

You can read more about the ways of XPIs installation here: http://getfireshot.com/using.php

------------------------
Regards, Evgeny Suslikov
http://suslikov.ru