pref("extensions.{0b457cAA-602d-484a-8fe7-c1d894a011ba}.description", "chrome://fireshot/locale/fireshot.properties");
pref("extensions.{0b457cAA-602d-484a-8fe7-c1d894a011ba}.translator", "chrome://fireshot/locale/fireshot.properties");
