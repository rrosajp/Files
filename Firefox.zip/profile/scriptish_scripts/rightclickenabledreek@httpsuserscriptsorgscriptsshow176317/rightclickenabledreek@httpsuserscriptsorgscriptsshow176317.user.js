// ==UserScript==
// @name Right Click Enabled | Reek
// @description Right click enabled / Click droit activé
// @version 1.0
// @license GPL version 3
// @encoding utf-8
// @icon http://www.gravatar.com/avatar/afb8376a9f634cd3501af4387de6425f.png
// @namespace https://userscripts.org/scripts/show/176317
// @updateURL https://userscripts.org/scripts/source/176317.meta.js
// @downloadURL https://userscripts.org/scripts/source/176317.user.js
// @include http*://*
// ==/UserScript==
/*=====================================================
  RUN
======================================================*/

  unsafeWindow.document.oncontextmenu = false;