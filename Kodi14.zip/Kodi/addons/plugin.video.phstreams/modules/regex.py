# -*- coding: utf-8 -*-

'''
    Genesis Add-on
    Copyright (C) 2015 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import urllib2
import re

try:
    import CommonFunctions as common
except:
    import commonfunctionsdummy as common



def GETURL(url, referer='', post=None):
    try:
        headers = {}
        headers['referer'] = referer
        headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0'
        request = urllib2.Request(url, data=post, headers=headers)
        response = urllib2.urlopen(request, timeout=60)
        result = response.read()
        response.close()
        return result
    except:
        return



def worker(data):
    try:
        data = str(data).replace('\r','').replace('\n','').replace('\t','')
        doregex = re.compile('\$doregex\[(.+?)\]').findall(data)
    except:
        return

    for i in range(0, 5):
        for x in doregex:
            try:
                if not '$doregex[%s]' % x in data: raise Exception()

                regex = re.compile('<regex>(.+?)</regex>').findall(data)
                regex = [r for r in regex if '<name>%s</name>' % x in r][0]

                if '$doregex' in regex: raise Exception()

                expres = re.compile('<expres>(.+?)</expres>').findall(regex)[0]

                try: referer = re.compile('<referer>(.+?)</referer>').findall(regex)[0]
                except: referer = ''
                referer = urllib.unquote_plus(referer)
                referer = common.replaceHTMLCodes(referer)
                referer = referer.encode('utf-8')

                page = re.compile('<page>(.+?)</page>').findall(regex)[0]
                page = urllib.unquote_plus(page)
                page = common.replaceHTMLCodes(page)
                page = page.encode('utf-8')

                result = GETURL(page, referer=referer)
                result = str(result).replace('\r','').replace('\n','').replace('\t','')
                result = str(result).replace('\/','/')

                r = re.compile(expres).findall(result)[0]
                data = data.replace('$doregex[%s]' % x, r)
            except:
                pass

    url = re.compile('(.+?)<regex>').findall(data)[0]
    url = common.replaceHTMLCodes(url)
    url = url.encode('utf-8')
    return url


